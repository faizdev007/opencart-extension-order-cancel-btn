Version 1.0 - OCMOD version by FaizDev007

Adds the ability to provide order cancel button on customer orders.

If you want to contribute just send your modifications.

The script is free for personal/business use but not for any other purpose (modifications, sale, etc).


Installing steps!

//////////////////////////////////////////////

1. Upload extention file.

2. Go to Modifications clear and refresh it.

3. Your good to go. Now check your Orders.

/////////////////////////////////////////////


This Plugin is perfectly work with default opencart and Juarnal theme. feel free to use with other theme. and if have any issue you can submit you issue with me I will solve as soon as posible.

If you Like my work you can rating it. And I will come with next version of this plugin and other plugin in future. 